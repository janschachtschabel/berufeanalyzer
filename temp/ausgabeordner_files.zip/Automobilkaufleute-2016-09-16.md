### R A H M E N L E H R P L A N 

 für den Ausbildungsberuf

 Automobilkaufmann und Automobilkauffrau

 (Beschluss der Kultusministerkonferenz vom 16.09.2016)

Sekretariat der Ständigen Konferenz der Kultusminister der Länder in der Bundesrepublik Deutschland

Taubenstraße 10 · 10117 Berlin Graurheindorfer Straße 157 · 53117 Bonn
Postfach 11 03 42 · 10833 Berlin Postfach 22 40 · 53012 Bonn


-----

### Teil I Vorbemerkungen

Dieser Rahmenlehrplan für den berufsbezogenen Unterricht der Berufsschule ist durch die
Ständige Konferenz der Kultusminister der Länder beschlossen worden und mit der entsprechenden Ausbildungsordnung des Bundes (erlassen vom Bundesministerium für Wirtschaft
und Energie oder dem sonst zuständigen Fachministerium im Einvernehmen mit dem Bundesministerium für Bildung und Forschung) abgestimmt.

Der Rahmenlehrplan baut grundsätzlich auf dem Niveau des Hauptschulabschlusses bzw.
vergleichbarer Abschlüsse auf. Er enthält keine methodischen Festlegungen für den Unterricht. Der Rahmenlehrplan beschreibt berufsbezogene Mindestanforderungen im Hinblick auf
die zu erwerbenden Abschlüsse.

Die Ausbildungsordnung des Bundes und der Rahmenlehrplan der Kultusministerkonferenz
sowie die Lehrpläne der Länder für den berufsübergreifenden Lernbereich regeln die Ziele
und Inhalte der Berufsausbildung. Auf diesen Grundlagen erwerben die Schüler und Schülerinnen den Abschluss in einem anerkannten Ausbildungsberuf sowie den Abschluss der Berufsschule.

Die Länder übernehmen den Rahmenlehrplan unmittelbar oder setzen ihn in eigene Lehrpläne um. Im zweiten Fall achten sie darauf, dass die Vorgaben des Rahmenlehrplanes zur
fachlichen und zeitlichen Abstimmung mit der jeweiligen Ausbildungsordnung erhalten bleiben.


-----

### Teil II Bildungsauftrag der Berufsschule

Die Berufsschule und die Ausbildungsbetriebe erfüllen in der dualen Berufsausbildung einen
gemeinsamen Bildungsauftrag.

Die Berufsschule ist dabei ein eigenständiger Lernort, der auf der Grundlage der Rahmenvereinbarung über die Berufsschule (Beschluss der Kultusministerkonferenz vom
12.03.2015) agiert. Sie arbeitet als gleichberechtigter Partner mit den anderen an der Berufsausbildung Beteiligten zusammen und hat die Aufgabe, den Schülern und Schülerinnen
berufsbezogene und berufsübergreifende Handlungskompetenz zu vermitteln. Damit werden
die Schüler und Schülerinnen zur Erfüllung der spezifischen Aufgaben im Beruf sowie zur
Mitgestaltung der Arbeitswelt und der Gesellschaft in sozialer, ökonomischer und ökologischer Verantwortung, insbesondere vor dem Hintergrund sich wandelnder Anforderungen,
befähigt. Das schließt die Förderung der Kompetenzen der jungen Menschen

� zur persönlichen und strukturellen Reflexion,
� zum lebensbegleitenden Lernen,
� zur beruflichen sowie individuellen Flexibilität und Mobilität im Hinblick auf das Zusammenwachsen Europas

ein.

Der Unterricht der Berufsschule basiert auf den für jeden staatlich anerkannten Ausbildungsberuf bundeseinheitlich erlassenen Ordnungsmitteln. Darüber hinaus gelten die für die Berufsschule erlassenen Regelungen und Schulgesetze der Länder.

Um ihren Bildungsauftrag zu erfüllen, muss die Berufsschule ein differenziertes Bildungsangebot gewährleisten, das

  - in didaktischen Planungen für das Schuljahr mit der betrieblichen Ausbildung abgestimmte handlungsorientierte Lernarrangements entwickelt,

  - einen inklusiven Unterricht mit entsprechender individueller Förderung vor dem Hintergrund unterschiedlicher Erfahrungen, Fähigkeiten und Begabungen aller Schüler und
Schülerinnen ermöglicht,

  - für Gesunderhaltung sowie spezifische Unfallgefahren in Beruf, für Privatleben und
Gesellschaft sensibilisiert,

 - Perspektiven unterschiedlicher Formen von Beschäftigung einschließlich unternehmerischer Selbstständigkeit aufzeigt, um eine selbstverantwortliche Berufs- und
Lebensplanung zu unterstützen,

  - an den relevanten wissenschaftlichen Erkenntnissen und Ergebnissen im Hinblick auf
Kompetenzentwicklung und Kompetenzfeststellung ausgerichtet ist.

Zentrales Ziel von Berufsschule ist es, die Entwicklung umfassender Handlungskompetenz
zu fördern. Handlungskompetenz wird verstanden als die Bereitschaft und Befähigung des
Einzelnen, sich in beruflichen, gesellschaftlichen und privaten Situationen sachgerecht
durchdacht sowie individuell und sozial verantwortlich zu verhalten.


-----

**Handlungskompetenz entfaltet sich in den Dimensionen von Fachkompetenz, Selbstkom-**
petenz und Sozialkompetenz.

**Fachkompetenz**
Bereitschaft und Fähigkeit, auf der Grundlage fachlichen Wissens und Könnens Aufgaben
und Probleme zielorientiert, sachgerecht, methodengeleitet und selbstständig zu lösen und
das Ergebnis zu beurteilen.

**Selbstkompetenz[1]**
Bereitschaft und Fähigkeit, als individuelle Persönlichkeit die Entwicklungschancen, Anforderungen und Einschränkungen in Familie, Beruf und öffentlichem Leben zu klären, zu durchdenken und zu beurteilen, eigene Begabungen zu entfalten sowie Lebenspläne zu fassen
und fortzuentwickeln. Sie umfasst Eigenschaften wie Selbstständigkeit, Kritikfähigkeit, Selbstvertrauen, Zuverlässigkeit, Verantwortungs- und Pflichtbewusstsein. Zu ihr gehören insbesondere auch die Entwicklung durchdachter Wertvorstellungen und die selbstbestimmte Bindung an Werte.

**Sozialkompetenz**
Bereitschaft und Fähigkeit, soziale Beziehungen zu leben und zu gestalten, Zuwendungen
und Spannungen zu erfassen und zu verstehen sowie sich mit anderen rational und verantwortungsbewusst auseinanderzusetzen und zu verständigen. Hierzu gehört insbesondere
auch die Entwicklung sozialer Verantwortung und Solidarität.

Methodenkompetenz, kommunikative Kompetenz und Lernkompetenz sind immanenter Bestandteil von Fachkompetenz, Selbstkompetenz und Sozialkompetenz.

**Methodenkompetenz**
Bereitschaft und Fähigkeit zu zielgerichtetem, planmäßigem Vorgehen bei der Bearbeitung
von Aufgaben und Problemen (zum Beispiel bei der Planung der Arbeitsschritte).

**Kommunikative Kompetenz**
Bereitschaft und Fähigkeit, kommunikative Situationen zu verstehen und zu gestalten. Hierzu
gehört es, eigene Absichten und Bedürfnisse sowie die der Partner wahrzunehmen, zu verstehen und darzustellen.

**Lernkompetenz**
Bereitschaft und Fähigkeit, Informationen über Sachverhalte und Zusammenhänge selbstständig und gemeinsam mit anderen zu verstehen, auszuwerten und in gedankliche Strukturen einzuordnen. Zur Lernkompetenz gehört insbesondere auch die Fähigkeit und Bereitschaft, im Beruf und über den Berufsbereich hinaus Lerntechniken und Lernstrategien zu
entwickeln und diese für lebenslanges Lernen zu nutzen.

1 Der Begriff „Selbstkompetenz“ ersetzt den bisher verwendeten Begriff „Humankompetenz“. Er berücksichtigt
stärker den spezifischen Bildungsauftrag der Berufsschule und greift die Systematisierung des DQR auf.


-----

### Teil III Didaktische Grundsätze

Um dem Bildungsauftrag der Berufsschule zu entsprechen werden die jungen Menschen zu
selbstständigem Planen, Durchführen und Beurteilen von Arbeitsaufgaben im Rahmen ihrer
Berufstätigkeit befähigt.

Lernen in der Berufsschule zielt auf die Entwicklung einer umfassenden Handlungskompetenz. Mit der didaktisch begründeten praktischen Umsetzung - zumindest aber der gedanklichen Durchdringung - aller Phasen einer beruflichen Handlung in Lernsituationen wird dabei
Lernen in und aus der Arbeit vollzogen.

Handlungsorientierter Unterricht im Rahmen der Lernfeldkonzeption orientiert sich prioritär
an handlungssystematischen Strukturen und stellt gegenüber vorrangig fachsystematischem
Unterricht eine veränderte Perspektive dar. Nach lerntheoretischen und didaktischen Erkenntnissen sind bei der Planung und Umsetzung handlungsorientierten Unterrichts in Lernsituationen folgende Orientierungspunkte zu berücksichtigen:

  - Didaktische Bezugspunkte sind Situationen, die für die Berufsausübung bedeutsam
sind.

  - Lernen vollzieht sich in vollständigen Handlungen, möglichst selbst ausgeführt oder
zumindest gedanklich nachvollzogen.

  - Handlungen fördern das ganzheitliche Erfassen der beruflichen Wirklichkeit, zum Beispiel technische, sicherheitstechnische, ökonomische, rechtliche, ökologische, soziale
Aspekte.

  - Handlungen greifen die Erfahrungen der Lernenden auf und reflektieren sie in Bezug
auf ihre gesellschaftlichen Auswirkungen.

  - Handlungen berücksichtigen auch soziale Prozesse, zum Beispiel die Interessenerklärung oder die Konfliktbewältigung, sowie unterschiedliche Perspektiven der Berufs- und
Lebensplanung.


-----

### Teil IV Berufsbezogene Vorbemerkungen

Der vorliegende Rahmenlehrplan für die Berufsausbildung zum Automobilkaufmann und zur
Automobilkauffrau ist mit der Verordnung über die Berufsausbildung zum Automobilkaufmann und zur Automobilkauffrau vom 28.02.2017 (BGBl. I S. 318) abgestimmt.

Der Rahmenlehrplan für den Ausbildungsberuf Automobilkaufmann/Automobilkauffrau (Beschluss der Kultusministerkonferenz vom 27.03.1998) wird durch den vorliegenden Rahmenlehrplan aufgehoben.

In Ergänzung des Berufsbildes (Bundesinstitut für Berufsbildung unter http://www.bibb.de)
sind folgende Aspekte im Rahmen des Berufsschulunterrichtes bedeutsam:

Automobilkaufleute arbeiten in Betrieben der Kraftfahrzeugbranche, vorwiegend in Autohäusern, bei Fahrzeugimporteuren sowie Automobilherstellern.

Die Neuordnung ist erfolgt, um

   - einer stärkeren Geschäftsprozessorientierung,

   - der gestiegenen Bedeutung der Finanzdienstleistungen,

   - der stärkeren Berücksichtigung der Fahrzeugtechnik,

   - dem Ausbau des Internethandels und der Internationalisierung,

   - den höheren Anforderungen an die kommunikative Kompetenz,

   - den veränderten rechtlichen Rahmenbedingungen,

   - sowie neuen Mobilitätsdienstleistungen
zu entsprechen.

Der Rahmenlehrplan ist nach Handlungsfeldern zusammengehöriger Arbeits- und Geschäftsprozesse strukturiert und am Kompetenzverständnis des Deutschen Qualifikationsrahmens für lebenslanges Lernen orientiert. Aufgrund ihrer Prüfungsrelevanz sind die Lernfelder 1 bis 5 des Rahmenlehrplans vor Teil 1 der Abschlussprüfung zu unterrichten.

Die Lernfelder des Rahmenlehrplans beziehen sich auf berufliche Problemstellungen aus
den Geschäftsfeldern Teilevertrieb, Kundendienst sowie Fahrzeugvertrieb und Finanzdienstleistungen.

Die Lernfelder sind methodisch didaktisch so umzusetzen, dass sie zur beruflichen Handlungskompetenz führen. Die Kompetenzen beschreiben den Qualifikationsstand am Ende
des Lernprozesses und stellen den Mindestumfang dar. Inhalte sind in Kursivschrift nur dann
aufgeführt, wenn die in den Zielformulierungen beschriebenen Kompetenzen konkretisiert
oder eingeschränkt werden sollen.

In allen Lernfeldern werden die Dimensionen der Nachhaltigkeit - Ökonomie, Ökologie und
Soziales -, des wirtschaftlichen Denkens, der soziokulturellen Unterschiede und der Inklusion
berücksichtigt und sie beinhalten rechtliche, mathematische und kommunikative Aspekte

Der Erwerb von Fremdsprachenkompetenz, die Nutzung von Informations- und Kommunikationssystemen sowie von Standardsoftware sind integrierter Bestandteil der Lernfelder.


-----

### Teil V Lernfelder

|Übersicht über die Lernfelder für den Ausbildungsberuf Automobilkaufmann und Automobilkauffrau|Col2|Col3|Col4|Col5|
|---|---|---|---|---|
|Lernfelder Nr.||Zeitrichtwerte in Unterrichtsstunden 1. Jahr 2. Jahr 3. Jahr|||
|1|Den Betrieb präsentieren und die betriebliche Zu- sammenarbeit mitgestalten|80|||
|2|Bestände und Erfolgsvorgänge erfassen und den Jahresabschluss durchführen|80|||
|3|Teile und Zubehör beschaffen und lagern|80|||
|4|Teile und Zubehör verkaufen|80|||
|5|Werkstattaufträge entgegennehmen und kaufmän- nische Geschäftsprozesse organisieren||120||
|6|Neufahrzeuge disponieren und den Verkaufspro- zess durchführen||40||
|7|Gebrauchtfahrzeuge disponieren und bereitstellen||40||
|8|Finanzdienstleistungen anbieten||80||
|9|Personalwirtschaftliche Aufgaben wahrnehmen|||60|
|10|Wertschöpfungsprozesse erfolgsorientiert steuern|||80|
|11|Wirtschaftliche Einflüsse auf unternehmerische Entscheidungen beurteilen und danach handeln|||80|
|12|Kommunikationspolitische Maßnahmen gestalten|||60|
|Summen: insgesamt 880 Stunden||320|280|280|


-----

**Lernfeld 1:**


**Den Betrieb präsentieren und die be-**
**triebliche Zusammenarbeit mit-**
**gestalten**


**1. Ausbildungsjahr**

**Zeitrichtwert: 80 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, die Stellung von Un-**
**ternehmen in der Gesamtwirtschaft, den Aufbau und die Geschäftsbereiche des**
**Betriebes darzustellen, Arbeits- und Geschäftsprozesse zu erläutern sowie ihre Be-**
**rufsrolle mitzugestalten.**

Die Schülerinnen und Schüler verschaffen sich einen Überblick über die Möglichkeiten
und Grenzen wirtschaftlichen Handelns in Unternehmen (einfacher Wirtschaftskreislauf,
_ökonomisches Prinzip). Sie analysieren den Aufbau (Organisationsformen,_ _Vollmachten,_
_Rechtsform), die Aufgaben und Leistungen der Geschäftsfelder ihres Betriebes. Sie er-_
kunden die Rechts- und Wirtschaftsbeziehungen zwischen den Geschäftspartnern in der
Automobilbranche und die Wettbewerbssituation.

Sie ermitteln betriebliche Arbeitssicherheits- und Unfallverhütungsvorgaben, um Gefahren
für sich und andere zu erkennen und Fehler zu vermeiden. Darüber hinaus machen sie
sich kundig über die Aufgaben, Rechte und Pflichten der an der dualen Berufsausbildung
beteiligten Personen und Einrichtungen (Berufsbildungsgesetz, Ausbildungsverordnung,
_Jugendarbeitsschutzgesetz, Jugend- und Auszubildendenvertretung, Tarifvertrag)._

Sie erstellen Kriterienkataloge zur Gestaltung und Durchführung von Präsentationen.

Sie präsentieren ihre Ergebnisse, bewerten die Präsentationen anhand der Kriterien und
erkennen Optimierungsmöglichkeiten. Sie gehen konstruktiv mit Kritik um.

Sie reflektieren ihre Aufgaben und ihre Position im Betrieb. Sie respektieren gesellschaftliche, ökonomische und ökologische Anforderungen an ihre Berufsrolle und leiten daraus
eigene Wertvorstellungen ab.


-----

**Lernfeld 2:**


**Bestände und Erfolgsvorgänge erfas-**
**sen und den Jahresabschluss durch-**
**führen**


**1. Ausbildungsjahr**
**Zeitrichtwert: 80 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, Geschäftsfälle unter**
**Beachtung der Grundsätze ordnungsmäßiger Buchführung und der Umsatzsteuer**
**zu dokumentieren und den buchhalterischen Jahresabschluss durchzuführen.**

Die Schülerinnen und Schüler analysieren den Aufbau der Bilanz (Anlage- und Umlauf_vermögen, Eigen- und Fremdkapital)._

Sie planen die Inventur (zeitnahe Stichtagsinventur, vor– und nachverlegte Inventur, per_manente Inventur), bereiten das Inventar vor und leiten die Bilanz ab. Dabei berücksichti-_
gen sie die rechtlichen Vorschriften.

Sie erfassen die im Unternehmen anfallenden Geschäftsfälle und kontieren die Belege.
Dazu führen sie das Kassenbuch, dokumentieren und kontrollieren Zahlungseingänge
und -ausgänge. Sie buchen Bestands- und Erfolgsvorgänge unter Berücksichtigung der
Umsatzsteuer und ermitteln den buchhalterischen Gewinn. Die Schülerinnen und Schüler
erstellen eine Gewinn- und Verlustrechnung sowie die Schlussbilanz. Sie reflektieren anhand der Änderungen von Vermögen und Schulden den Erfolg im abgelaufenen Geschäftsjahr.

Sie kontrollieren ihre Arbeitsergebnisse, bewerten sie hinsichtlich Genauigkeit und Vollständigkeit und ergreifen Verbesserungsmaßnahmen.


-----

**Lernfeld 3:**


**Teile und Zubehör beschaffen und lagern**


**1. Ausbildungsjahr**

**Zeitrichtwert: 80 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, den Einkauf und die**
**Lagerung von Teilen und Zubehör zu planen, durchzuführen und zu überwachen.**

Die Schülerinnen und Schüler analysieren den Bedarf an Teilen (original, qualitativ gleich_wertige, qualitativ unterschiedliche) und Zubehör unter Beachtung der Lagerkennzahlen_
und Bestellvorschlaglisten.

Sie bestimmen die optimalen Bestellmengen und Bestellzeitpunkte. Sie recherchieren und
nutzen unterschiedliche Bezugsquellen und schreiben Anfragen auf verschiedenen Kommunikationswegen, auch in einer Fremdsprache. Eingehende Angebote vergleichen und
bewerten sie nach quantitativen und qualitativen Kriterien.

Sie entscheiden sich für einen Lieferanten und schließen einen Kaufvertrag ab. Dabei beachten sie Rechtsnormen und deren Wirkung (Nichtigkeit, Anfechtbarkeit, Eigentum, Be_sitz) sowie die Allgemeinen Geschäftsbedingungen._

Sie überwachen und prüfen den Wareneingang, lagern die Waren ein und beachten hierbei die Lagerorganisationsprinzipien und die Grundsätze der Lagerhaltung.

Sie kontrollieren Eingangsrechnungen und veranlassen die situationsgerechte Bezahlung
(betrieblicher Zahlungsverkehr). Sie buchen den Wareneinkauf und den Rechnungsausgleich auch unter Berücksichtigung von Skonto.

Sie entwickeln bei mangelhaften Leistungen (Prüf- und Rügepflicht) und verspäteter Lieferung (Leistungsverzug) geeignete Lösungsvorschläge und kommunizieren bei deren Umsetzung mit den Vertragspartnern.

Die Schülerinnen und Schüler beurteilen Beschaffungs-und Lagerprozesse hinsichtlich
nachhaltiger Wirkungen und zeigen begründete Möglichkeiten zur Optimierung von _Wirt-_
_schaftlichkeit und Umweltschutz auf._

Sie reflektieren ihre Mitverantwortung für Menschen und Umwelt im Zusammenhang mit
Beschaffungs- und Lagerprozessen.


-----

**Lernfeld 4:**


**Teile und Zubehör verkaufen** **1. Ausbildungsjahr**

**Zeitrichtwert: 80 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, den Verkauf von Tei-**
**len und Zubehör kundenorientiert durchzuführen.**

Die Schülerinnen und Schüler analysieren das Sortiment (Breite, Tiefe) und gestalten den
Verkaufsraum mit Teilen und Zubehör.

Sie begrüßen die Kunden und ermitteln ihre Bedarfe. Bei der Vorlage der Ware argumentieren sie mit Hilfe von Produktinformationen. Auf Kundeneinwände reagieren sie situationsgerecht, weisen auf Ergänzungsartikel hin und verabschieden die Kunden, auch in
einer Fremdsprache. Sie nutzen Techniken der Gesprächsführung.

Sie erstellen Rechnungen und Lieferscheine und bieten den Kunden verschiedene Zahlungsmöglichkeiten an. Sie buchen den Warenverkauf und den Rechnungsausgleich auch
unter Berücksichtigung von Skonto.

Sie überwachen die Erfüllung von Kaufverträgen, entwickeln geeignete Lösungsvorschläge bei identifizierten Kaufvertragsstörungen (Sachmangelhaftung, _Nicht-Rechtzeitig-_
_Zahlung, Annahmeverzug) und kommunizieren bei deren Umsetzung mit den Vertrags-_
partnern (Mahnwesen, Verjährung).

Sie reflektieren und beurteilen die Verkaufsprozesse hinsichtlich Wirtschaftlichkeit und
ihrer Mitverantwortung für Gesellschaft und Umwelt. Dazu präsentieren sie ihr Vorgehen
und die Ergebnisse für die betriebsinterne Nutzung.


-----

**Lernfeld 5:**


**Werkstattaufträge entgegennehmen**
**und kaufmännische Geschäftsprozes-**
**se organisieren**


**2. Ausbildungsjahr**

**Zeitrichtwert: 120 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, Kundenwünsche zu**
**bearbeiten, an Arbeitsprozessen in der Werkstatt unterstützend mitzuwirken und**
**eine ordnungsgemäße Fahrzeugübergabe an den Kunden sicherzustellen.**

Die Schülerinnen und Schüler analysieren das Anliegen des Kunden, auch in einer
Fremdsprache und koordinieren die weitere Bearbeitung auf der Basis betrieblicher Vorgaben (Prozessabläufe). Dabei unterscheiden sie Arbeitsaufgaben, die nur von fachlich
ausgewiesenen Personen (Elektrotechnik, Sicherheitstechnik, alternative Antriebe, Prüf_dienste), durchgeführt werden dürfen von Routineaufgaben ohne spezielle Befähigungs-_
nachweise.

Sie informieren sich über das Kundenfahrzeug auf der Grundlage der Fahrzeughistorie,
von Daten aus technischen Unterlagen sowie aus Fahrzeugpapieren hinsichtlich mechanischer, hydraulischer, pneumatischer sowie elektrischer, elektronischer Systeme und
Funktionseinheiten und berücksichtigen ihr Zusammenwirken.

Sie wählen das für den Kunden passende Angebot der Werkstatt aus (Verkehrs- und Be_triebssicherheit, Rückrufaktion, Inspektion, Schadensbearbeitung, Reparatur, zeitwertge-_
_rechte Reparatur, Sachmangelhaftungs- und Garantieauftrag, Kulanzanfrage). Dabei zei-_
gen sie Empathie für die Situation des Kunden und handeln interessenausgleichend
(Kundenorientierung, Kundenzufriedenheit, Kundenbindung).

Die Schülerinnen und Schüler erstellen Kostenvoranschläge und Aufträge. Sie bereiten
die Rechnung inhaltlich (Teile- und Arbeitsposition) und rechnerisch (Nettowert, Umsatz_steuer, Altteilesteuer, Bruttowert) vor._ Bei der Erfassung und Pflege der Kunden- und
Fahrzeugdaten beachten sie den Datenschutz.

Sie führen das Kundengespräch durch und erläutern dem Kunden den Inhalt von Verträgen (Werkvertrag) und Reparaturbedingungen. Auf Wunsch organisieren sie die Ersatzmobilität des Kunden. Sie koordinieren den innerbetrieblichen Ablauf des Kundenauftrags
(Termine, Dialogannahme, _Teileverfügbarkeit, Fremdleistungen, Versicherungsabwick-_
_lung) und informieren den Kunden über Reparaturerweiterungen. Sie erläutern die Rech-_
nung kundenorientiert in kaufmännischer (Arbeitswerte, Zeiteinheiten) und technischer
Hinsicht (Herstellervorgaben, gesetzliche Vorschriften), wickeln den Zahlungsvorgang ab
und übergeben das Fahrzeug.

Sie buchen Werkstattrechnungen der internen und externen Aufträge.

In Zusammenarbeit mit der Werkstatt wirken sie an der umweltgerechten Entsorgung von
Fahrzeugen und Gefahrstoffen unter Beachtung von gesetzlichen-, lieferanten- und herstellerbezogenen Vorgaben mit. Sie entwickeln Verantwortungsbewusstsein für die Sicherheit am Arbeitsplatz und den schonenden Umgang mit Ressourcen.

Sie reflektieren ihre Ergebnisse hinsichtlich der Einhaltung betrieblicher Vorgaben. Dabei
ziehen sie Konsequenzen für das eigene Vorgehen als Beitrag zur Kundenzufriedenheit
und Kundenbindung.

Sie entwickeln und diskutieren Verbesserungsvorschläge für die Abläufe im Unternehmen im Spannungsfeld von humanen Arbeitsbedingungen, Umweltschutz und betrieblichem Erfolg.


-----

**Lernfeld 6:**


**Neufahrzeuge disponieren und den Ver-**
**kaufsprozess durchführen**


**2. Ausbildungsjahr**

**Zeitrichtwert: 40 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, Beschaffungs- und**
**Verkaufsprozesse von Neufahrzeugen und Maßnahmen zur Kundennachbetreuung**
**durchzuführen.**

Die Schülerinnen und Schüler analysieren die Marktsituation (Modellpolitik des Herstel_lers, Produktlebenszyklus, Portfolioanalyse), um eine Auswahl an Neufahrzeugen (fabrik-_
_neue Fahrzeuge, Ausstellungsfahrzeuge, Lagerfahrzeuge, Reimporte) bereitstellen zu_
können. Dabei berücksichtigen sie verschiedene Mobilitätskonzepte.

Sie planen die Fahrzeugauswahl (Modelle, Mengen) und legen sie mit den Beschaffungszeitpunkten in einem Beschaffungsplan fest. Dabei berücksichtigen sie die Lieferbereitschaft des Herstellers und die vertraglichen Vereinbarungen (Händlerverträge, Ab_satzmengenvereinbarungen, Rückkaufvereinbarungen). In ihre Planungen beziehen sie_
auch finanzwirtschaftliche Einflussfaktoren ein (Margensysteme und Verkaufsprogramme
_der Hersteller, Kapitalbedarf für das Neuwagengeschäft, Zahlungsbedingungen)._

Sie führen die Fahrzeugbestellung auf typischen Beschaffungswegen durch, wirken bei
der Vertragsabwicklung mit und organisieren den ausstellungsfertigen Zustand der Neufahrzeuge. Sie beraten den Kunden bei der Fahrzeugauswahl sowie bei der Konfiguration,
sorgen für eine positive Gesprächsatmosphäre auch unter Berücksichtigung interkultureller Hintergründe. Dabei erklären sie technische Merkmale (Antriebs- und Fahrwerkssys_teme, Komfort- und Sicherheitssysteme) im Hinblick auf Kundenwünsche und gesell-_
schaftliche Rahmenbedingungen (Energieverbrauch, Ökobilanz, Gesetzgebung, Konnek_tivität)._

Die Schülerinnen und Schüler bereiten die Vertragsunterlagen für den Verkaufsprozess
vor (Verbindliche Bestellung, Allgemeine Geschäftsbedingungen für Neufahrzeuge, Auf_tragsbestätigung), stellen die Fahrzeugen für Probefahrten bereit, führen Fahrzeugzulas-_
sungen durch und sorgen für die technische, optische und kaufmännische Vorbereitung
der Auslieferung verkaufter Neufahrzeuge (Vertrags- und Fahrzeugunterlagen, Geldwä_schegesetz). Sie buchen das Neufahrzeuggeschäft. Darüber hinaus betreuen sie Kunden_
zeitlich und inhaltlich nach und dokumentieren den Vorgang (Kundenzufriedenheitsbefra_gungen, Aftersales, Datenschutz)._

Sie reflektieren die Entscheidungen zur Fahrzeugdisposition und den Beratungsvorgang
beim Verkauf von Neufahrzeugen. Dabei entwickeln sie Handlungsalternativen für ihr
Vorgehen zur Erhöhung der betrieblichen Zielerreichungsgrade im Neuwagengeschäft.


-----

**Lernfeld 7:**


**Gebrauchtfahrzeuge disponieren und**
**bereitstellen**


**2. Ausbildungsjahr**

**Zeitrichtwert: 40 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, Gebrauchtfahrzeuge**
**zu beschaffen, ihren Bestand zu überwachen und für den Vertrieb bereitzustellen.**

Die Schülerinnen und Schüler analysieren den Gebrauchtfahrzeugmarkt (Wettbewerber,
_gesellschaftliche Trends) und nutzen betriebsinterne Daten (Verkaufsstatistik, Umsatz-_
_entwicklung), um ein zielgruppengerechtes Sortiment an Gebrauchtfahrzeugen bereitstel-_
len zu können.

Sie informieren sich über betriebliche Zielsetzungen für den Gebrauchtfahrzeugbereich
(Absatzzahlen, Bruttoertrag, Gebrauchtfahrzeugprogrammvorgaben der Hersteller), Beschaffungs- und Absatzwege, Bezugsquellen sowie finanzwirtschaftliche Einflussfaktoren
(Kapitalbedarf für das Gebrauchtfahrzeuggeschäft, Zahlungsbedingungen). Sie ermitteln
die Informationen zu Standzeiten von Gebrauchtfahrzeugen (intern, extern).

Die Schülerinnen und Schüler planen die Fahrzeugauswahl kriteriengeleitet (quantitativ,
_qualitativ), auch von Handelspartnern anderer europäischer Länder. Sie schätzen den_
wirtschaftlichen Erfolg der Maßnahme ein (Gebrauchtfahrzeugvorkalkulation) und konzeptionieren die Präsentation der Gebrauchtfahrzeuge.

Sie wirken bei der kaufmännischen Gebrauchtfahrzeugbewertung und der Ankaufsvertragsabwicklung mit. Sie sorgen für den ausstellungs- und auslieferungsfertigen Zustand
der Gebrauchtfahrzeuge und nehmen die Preisauszeichnung vor (interner Auftrag, Diffe_renz- und Regelbesteuerung). Dabei gestalten sie eine vorteilhafte Präsentation vor Ort_
und in Verkaufsportalen und halten medienrechtliche Regelungen ein. Sie kommunizieren
mit Kaufinteressenten kundenorientiert auf verschiedenen Kommunikationswegen. Die
Schülerinnen und Schüler unterstützen den Vertrieb durch die statistische Überwachung
der Standzeiten von Gebrauchtfahrzeugen, ergründen Ursachen sowie Folgen überdurchschnittlicher Standzeiten und schlagen geeignete Gegenmaßnahmen vor. Darüber
hinaus führen sie Nachkalkulationen erfolgter Gebrauchtfahrzeugverkäufe durch und buchen das Gebrauchtfahrzeuggeschäft.

Die Schülerinnen und Schüler prüfen ihre Ergebnisse und vergleichen den geplanten und
realisierten wirtschaftlichen Erfolg.

Sie reflektieren den Zielerreichungsgrad im Gebrauchtfahrzeuggeschäft und entwickeln
Handlungsalternativen.


-----

**Lernfeld 8:**


**Finanzdienstleistungen anbieten** **2. Ausbildungsjahr**

**Zeitrichtwert: 80 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, Angebote für Finan-**
**zierung, Leasing, Versicherungen und Garantieleistungen zu erstellen.**

Die Schülerinnen und Schüler analysieren die Kundenwünsche und ermitteln den Bedarf
an Finanzdienstleistungen.

Sie informieren gewerbliche und private Kunden über verschiedene Finanzierungsmodelle
(Standardfinanzierung, 2- und 3-Wege-Finanzierung) und Leasingmodelle (Restwertlea_sing, Kilometerleasing). Sie erläutern branchentypische Versicherungsprodukte (Haft-_
_pflicht-, Kasko-, Restschuld-, Leasingraten-, GAP-Versicherung), deren Tarifmerkmale_
und zusätzlich erwerbbare Leistungen (Anschluss-, Gebrauchtwagen-, Mobilitätsgarantie,
_Full-Service-Leasing)._

Sie erstellen und kalkulieren Finanzdienstleistungsangebote und beraten die Kunden unter Abwägung der Interessen des eigenen Unternehmens und des Kunden. In diesem
Zusammenhang prüfen sie deren Kreditfähigkeit und Kreditwürdigkeit sowie benötigte
Sicherheiten (Sicherungsübereignung, Abtretung von Versicherungsleistungen, Mitdarle_hensnehmer, Bürgschaft). Sie erläutern den Kunden Vertragsbestandteile und das Wider-_
rufsrecht adressatengerecht. Die Schülerinnen und Schüler prüfen das Angebot und den
Geschäftsprozess auf Einhaltung betrieblicher Vorgaben. Sie reagieren auf den Handlungsbedarf während und am Ende der Vertragslaufzeit (Vertragsanpassung, -kündigung,
_-verlängerung, Fahrzeugrückgabe)._

Sie reflektieren ihr Vorgehen als Beitrag zur Kundenzufriedenheit sowie Kundenbindung
und diskutieren Verbesserungsvorschläge für die Abläufe im Unternehmen.


-----

**Lernfeld 9:**


**Personalwirtschaftliche Aufgaben wahr-**
**nehmen**


**3. Ausbildungsjahr**

**Zeitrichtwert: 60 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, Aufgaben der Perso-**
**nalverwaltung wahrzunehmen und bei Maßnahmen zur Personalbeschaffung und**
**-entwicklung sowie zur Beendigung von Beschäftigungsverhältnissen mitzuwirken.**

Die Schülerinnen und Schüler analysieren den Personalbestand, um personalwirtschaftliche Entscheidungen vorzubereiten. Dabei nutzen sie interne Statistiken.

Sie planen den quantitativen und qualitativen Personalbedarf unter Berücksichtigung betriebswirtschaftlicher Ziele und gesellschaftlicher Faktoren (Demografie, Inklusion, Migra_tion, Gleichstellung). Sie entscheiden über geeignete Wege der Personalbeschaffung (in-_
_tern, extern), formulieren Stellenanzeigen auf der Grundlage von Stellenbeschreibungen,_
auch in einer Fremdsprache und organisieren Auswahl- und Einstellungsverfahren unter
Beachtung arbeitsrechtlicher Vorschriften.

Sie wirken bei der Erstellung von Arbeits- und Ausbildungsverträgen mit und beachten
dabei tarif-, arbeits-, sozialversicherungs- und steuerrechtliche Regelungen. Sie erläutern
neuen Mitarbeiterinnen und Mitarbeitern wesentliche Inhalte der Gehaltsabrechnung, legen Personalakten an und führen diese unter besonderer Berücksichtigung des Datenschutzes. Sie ermitteln die Bestandteile des Bruttoentgelts unter Beachtung bestehender
rechtlicher Ansprüche (Arbeitsvertrag, Entgelttarifvertrag, Betriebsvereinbarung, Provisi_onssysteme) und berechnen das Nettoentgelt. Dabei beziehen sie sozialversicherungs-_
rechtliche und steuerliche Regelungen vor dem Hintergrund der sozialen Sicherung und
der privaten Vorsorge ein.

Die Schülerinnen und Schüler planen den Personaleinsatz und berücksichtigen dabei gesetzliche Regelungen (Arbeitszeitgesetz, _Mutterschutzgesetz, Elternzeitgesetz, Schwer-_
_behindertenrecht, Arbeitsschutzgesetz, Bundesurlaubsgesetz). Sie ermitteln und doku-_
mentieren Arbeits- und Abwesenheitszeiten und bereiten sie zur Auswertung vor. Sie
entwickeln Konzepte zur Personalförderung und beraten Mitarbeiterinnen und Mitarbeiter
zu Fortbildungsmöglichkeiten.

Sie wirken bei Abmahnungen, der Beendigung von Arbeitsverhältnissen und der Erstellung von Arbeitszeugnissen mit. Dabei beachten sie das Betriebsverfassungsgesetz und
den Kündigungsschutz.

Sie bewerten ihr Auftreten und Verhalten gegenüber den Mitarbeiterinnen und Mitarbeitern selbstkritisch, identifizieren Konfliktpotenziale im personalwirtschaftlichen Bereich und
entwickeln Lösungsansätze.

Sie reflektieren ihre eigene Position als Arbeitnehmer in der Gesellschaft.


-----

**Lernfeld 10:**


**Wertschöpfungsprozesse erfolgsorien-**
**tiert steuern**


**3. Ausbildungsjahr**

**Zeitrichtwert: 80 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, die betriebliche Kos-**
**ten- und Leistungsrechnung durchzuführen und mit Hilfe von Kennzahlen die Ge-**
**schäftsfelder des Unternehmens zu steuern.**

Die Schülerinnen und Schüler analysieren Kostenarten (kalkulatorische Kosten, _Einzel-_
_und Gemeinkosten) und Leistungen im Unternehmen und ermitteln hieraus das Betriebs-_
ergebnis.

Sie erstellen im Rahmen der Vollkostenrechnung einen Betriebsabrechnungsbogen. Sie
ermitteln Zuschlagsätze für alle Kostenstellen und wenden sie in der Preiskalkulation
(Vorwärts-, Rückwärts- und Differenzkalkulation, Kalkulationsfaktor, Handelsspanne) an.
Sie führen im Rahmen der Teilkostenrechnung eine kurzfristige Erfolgsrechnung (Break_Even-Point,_ _Deckungsbeiträge I, II und III, Betriebsergebnis) durch. Sie beurteilen die_
Werte und reflektieren betriebliche Maßnahmen zur Verbesserung der Ergebnisse.

Im Geschäftsfeld Teilevertrieb wählen sie relevante Kennzahlen (durchschnittlicher La_gerbestand, Lagerdauer, Umschlagshäufigkeit, Kosten der Kapitalbindung) aus und beur-_
teilen den Erfolg des Teilelagers.

Im Neu- und Gebrauchtfahrzeugbereich vergleichen sie den Bruttoertrag und den Deckungsbeitrag III. Sie erstellen Umsatz- und Absatzstatistiken.

Im Werkstattbereich ermitteln sie die Stundenverrechnungssätze (Werkstattindex, _Soll-_
_Lohnerlöse, Werkstatt-Schnittlohn, Servicegrad) und überprüfen die Kalkulation unter-_
schiedlicher Werkstattaufträge (interne und externe Wartungs- und Instandsetzungsarbei_ten, Garantieaufträge, Reparatur mit Austauschteilen)._

Sie beurteilen die wirtschaftliche Situation des Unternehmens anhand von Kennzahlen
aus den einzelnen Geschäftsfeldern, deren Wechselwirkung untereinander und bereiten
sie für weitere unternehmerische Entscheidungen auf. Unter Berücksichtigung von Branchen- und Zeitvergleich schlagen sie der Geschäftsleitung Maßnahmen zur Verbesserung vor.


-----

**Lernfeld 11:**


**Wirtschaftliche Einflüsse auf unterneh-**
**merische Entscheidungen beurteilen**
**und danach handeln**


**3. Ausbildungsjahr**

**Zeitrichtwert: 80 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, Einflüsse gesamt-**
**wirtschaftlicher Rahmenbedingungen zu analysieren, deren Auswirkungen auf die**
**wirtschaftliche Situation des Unternehmens und die Branche zu beurteilen und**
**Konsequenzen für das unternehmerische und private Handeln zu ziehen.**

Die Schülerinnen und Schüler analysieren Zielsetzungen und Zusammenwirken der Wirtschaftssektoren im vollständigen Wirtschaftskreislauf sowie die Bedeutung ihres Unternehmens innerhalb der gesamtwirtschaftlichen Rahmenbedingungen. Dabei berücksichtigen sie den wirtschaftlichen und gesellschaftlichen Stellenwert der Automobilbranche
auf nationaler und internationaler Ebene.

Sie zeigen Beziehungen zwischen Inlandsprodukt, Nationaleinkommen, Einkommensentstehung, -verteilung sowie -verwendung auf und beurteilen die Bedeutung der Automobilbranche für Wachstum und Beschäftigung in Deutschland. In diesem Zusammenhang
ziehen sie Schlüsse aus technologischen Entwicklungen und Wirkungen der Digitalisierung.

Sie interpretieren den Kraftfahrzeugmarkt als Ort des Zusammentreffens von Angebot
und Nachfrage und untersuchen das Zusammenwirken von Markt und Preis. Sie ordnen
die Situation des Betriebes im Markt ein und schlagen Maßnahmen zur Verbesserung der
Unternehmensposition auf dem globalisierten Automobilmarkt unter Beachtung des
Wettbewerbsrechts (Gesetz gegen Wettbewerbsbeschränkungen, Gruppenfreistellungs_Verordnung) vor._

Die Schülerinnen und Schüler prüfen die Auswirkungen von staatlicher Wirtschaftspolitik
und der Geldpolitik des Europäischen Systems der Zentralbanken auf die konjunkturelle
Entwicklung in der sozialen Marktwirtschaft. Sie reflektieren die Auswirkungen auf die
wirtschaftliche Situation von Unternehmen der Automobilbranche, von Haushalten und ihr
berufliches sowie privates Handeln.


-----

**Lernfeld 12:**


**Kommunikationspolitische Maßnahmen**
**gestalten**


**3. Ausbildungsjahr**

**Zeitrichtwert: 60 Stunden**


**Die Schülerinnen und Schüler verfügen über die Kompetenz, durch kommunikati-**
**onspolitische Maßnahmen Kunden zu gewinnen und zu binden.**

Die Schülerinnen und Schüler werten Daten der Marktforschung (Primär- _und Sekundär-_
_forschung) aus, erfassen neue Kundendaten und entwickeln eigene Befragungen (Kun-_
_denzufriedenheit). Dabei berücksichtigen sie die aktuelle Marktsituation (Kundenstruktur,_
_Wettbewerber, wirtschaftliche Rahmenbedingungen) und nehmen den Kunden als wich-_
tigen Partner wahr (Kundenbeziehungsmanagement).

Sie planen den Einsatz von Maßnahmen der Kommunikationspolitik und erstellen einen
Werbeplan.

Sie gestalten Werbemittel, berücksichtigen die Grundsätze der Werbung und rechtliche
Rahmenbedingungen (Gesetz gegen den Unlauteren Wettbewerb, Preisangabenverord_nung)._

Die Schülerinnen und Schüler präsentieren ihre Arbeitsergebnisse und begründen die
getroffenen Entscheidungen.

Sie bewerten den Werbeerfolg, auch vor dem Hintergrund rechtlicher Grenzen und ethischer Aspekte. Sie diskutieren alternative Vorgehensweisen und respektieren die Wertvorstellungen anderer. Dabei reflektieren sie den Zusammenhang der kommunikationspolitischen Maßnahmen mit den anderen Instrumenten des Marketing-Mix.


-----

### Teil VI Lesehinweise


-----

# Liste der Entsprechungen

## zwischen

 dem Rahmenlehrplan für die Berufsschule und dem Ausbildungsrahmenplan für den Betrieb
 im Ausbildungsberuf Automobilkaufmann und Automobilkauffrau

### Die Liste der Entsprechungen dokumentiert die Abstimmung der Lerninhalte zwi- schen den Lernorten Berufsschule und Ausbildungsbetrieb.
 Charakteristisch für die duale Berufsausbildung ist, dass die Auszubildenden ihre Kompetenzen an den beiden Lernorten Berufsschule und Ausbildungsbetrieb erwer- ben. Hierfür existieren unterschiedliche rechtliche Vorschriften:
 • Der Lehrplan in der Berufsschule richtet sich nach dem Rahmenlehrplan der Kul- tusministerkonferenz.
 • Die Vermittlung im Betrieb geschieht auf der Grundlage des Ausbildungsrahmen- plans, der Bestandteil der Ausbildungsordnung ist.
 Beide Pläne wurden in einem zwischen der Bundesregierung und der Kultusminister- konferenz gemeinsam entwickelten Verfahren zur Abstimmung von Ausbildungsord- nungen und Rahmenlehrplänen im Bereich der beruflichen Bildung ("Gemeinsames Ergebnisprotokoll") von sachkundigen Lehrerinnen und Lehrern sowie Ausbilderinnen und Ausbildern in ständiger Abstimmung zueinander erstellt.
 In der folgenden Liste der Entsprechungen sind die Lernfelder des Rahmenlehrplans den Positionen des Ausbildungsrahmenplans so zugeordnet, dass die zeitliche und sachliche Abstimmung deutlich wird. Sie kann somit ein Hilfsmittel sein, um die Ko- operation der Lernorte vor Ort zu verbessern und zu intensivieren.


-----

BIBB / Jordanski - jo
KMK / Dr.Ohlms - / Müller 
### Liste der Entsprechungen zwischen Ausbildungsrahmenplan und Rahmenlehrplan

der Berufsausbildung

zum Automobilkaufmann/
zur Automobilkauffrau

Ggf. Gliederungsüberschrift des Ausbildungsrahmenplanes

|Ausbildungsrahmenplan Stand : 23.5.2016|Col2|Col3|Rahmenlehrplan Stand: 23.5.2016|Col5|Col6|Col7|Col8|
|---|---|---|---|---|---|---|---|
|Teil des Ausbildungsberufsbildes|Zeitliche Zuord- nung 1.-15. 16.-36. Monat Monat||Schuljahr 1 2 3 4||||Lernfelder|
|||||||||
|1. Teile und Zubehör organisieren und verkaufen||||||||
|a) rechtliche und technische Vorgaben, betriebliche Regelungen, Datenverarbei- tungsprogramme und fremdsprachige Fachbegriffe anwenden|X||x||||LF 3, 4|
|b) in Abstimmung mit anderen Ge- schäftsfeldern den Einkauf planen und Bestellungen durchführen|X||x||||LF 3|
|c) Verkaufspreise mit vorgegebenen Zuschlagsätzen kalkulieren|X||x||||LF 3|
|d) Warenlieferungen annehmen, Wa- ren nach Art und Menge sowie auf offene Mängel prüfen und bei Beanstandungen betriebsübliche Maßnahmen einleiten|X||x||||LF 3|
|e) Wareneingänge dokumentieren und Waren insbesondere unter Einhaltung der Regeln des Umweltschutzes einlagern|X||x||||LF 3|
|f) Eingangsrechnungen auf Richtigkeit prüfen und Unstimmigkeiten klären|X||x||||LF 3|
|g) Teile und Zubehörlager unter Be- rücksichtigung der Sortimentspolitik und der Lagerkennzahlen organisieren|X||x||||LF 3|
|h) Liefertermine überwachen, kommu- nizieren und Maßnahmen bei Lieferungs- verzug einleiten|X||x||||LF 3|
|i) Material einem Auftrag zuordnen und ausgeben|X||x||||LF 3|


j) Kundenwünsche ermitteln, Kunden
und Kundinnen unter Nutzung von Produktinformationen beraten, Teile und


X x LF 4


-----

|Ausbildungsrahmenplan Stand : 23.5.2016|Col2|Col3|Rahmenlehrplan Stand: 23.5.2016|Col5|Col6|Col7|Col8|
|---|---|---|---|---|---|---|---|
|Teil des Ausbildungsberufsbildes|Zeitliche Zuord- nung 1.-15. 16.-36. Monat Monat||Schuljahr 1 2 3 4||||Lernfelder|
|||||||||
|Zubehör verkaufen und Rechnungen erstellen||||||||
|k) Präsentation von Zubehör planen und umsetzen|X||x||||LF 4|
|l) die eigene Vorgehensweise reflek- tieren und bewerten und Maßnahmen zur Optimierung ableiten|X||x||||LF 3, 4|
|2. An Werkstattprozessen mitwirken und als Schnittstelle zwischen Handel und Werkstatt agieren||||||||
|a) bei der Unterstützung der Werk- stattmitarbeiter und Werkstattmitarbeite- rinnen Arbeitsprozesse und Fahrzeug- technologien berücksichtigen sowie tech- nische Standards und gesetzliche Best- immungen einhalten|X|||x|||LF 5|
|b) Sichtprüfungen zur Verkehrs- und Betriebssicherheit von Fahrzeugen durch- führen|X|||x|||LF 5|
|c) mechanische, hydraulische, pneu- matische sowie elektrische und elektroni- sche Systeme in Fahrzeugen unterschei- den und ihre Funktion erläutern|X|||x|||LF 5|
|d) an Diagnose-, Wartungs-, Service- und Reparaturarbeiten mitwirken|X|||x|||LF 5|
|e) bei der Beanstandungs- und Scha- densaufnahme als Grundlage für die Erstellung von Kostenvoranschlägen mitwirken|X|||x|||LF 5|
|f) die umweltgerechte Entsorgung und das Recycling von Fahrzeugen, deren Komponenten und Betriebsstoffen orga- nisieren und dabei Hersteller- und Liefe- rantenvorgaben einhalten|X|||x|||LF 5|
|g) durchgeführte Reparatur- und Ser- vicearbeiten erläutern|X|||x|||LF 5|
|h) Werkstattprozesse reflektieren und Schlussfolgerungen für die kaufmänni- schen Arbeitsprozesse ableiten|X|||x|||LF 5|
|3. Kundendienst organisieren und Servicebereich unterstützen||||||||
|a) Qualitätsvorgaben im Kundenservice anwenden|X||x|x|||LF 4 - 8|


-----

|Ausbildungsrahmenplan Stand : 23.5.2016|Col2|Col3|Rahmenlehrplan Stand: 23.5.2016|Col5|Col6|Col7|Col8|
|---|---|---|---|---|---|---|---|
|Teil des Ausbildungsberufsbildes|Zeitliche Zuord- nung 1.-15. 16.-36. Monat Monat||Schuljahr 1 2 3 4||||Lernfelder|
|||||||||
|b) Informationssysteme unter Einhal- tung des Datenschutzes nutzen|X||x|x|||LF 4 - 8|
|c) Kundenwünsche, auch in einer Fremdsprache, ermitteln und die wei- tere Bearbeitung koordinieren|X||x|x|||LF 4 - 8|
|d) Werkstatt- und Serviceleistungen sowie zeitwertgerechte Reparatur- leistungen anbieten|X|||x|||LF 5|
|e) bei der Erstellung von Kostenvoran- schlägen mitwirken|X|||x|||LF 5|
|f) Kunden- und Fahrzeugdaten erfas- sen und pflegen|X|||x|||LF 5|
|g) Werkstattaufträge unter Berücksich- tigung von Daten aus technischen Unterlagen und Fahrzeugpapieren erstellen|X|||x|||LF 5|
|h) Termine planen und mit den zustän- digen Bereichen koordinieren;|X|||x|||LF 5|
|i) anforderungsbezogene Fremdleis- tungen organisieren|X|||x|||LF 5|
|j) die Prüfung der Teileverfügbarkeit bereits bei der Terminvergabe veran- lassen;|X|||x|||LF 5|
|k) die Kundenmobilität sicherzustellen|X|||x|||LF 5|
|l) Rechnungen erstellen und erläutern und Zahlungen entgegennehmen|X|||x|||LF 5|
|m) Zahlungen verbuchen und den Kas- senabschluss durchführen||X|x|x|x||LF 2, 5, 10|
|n) Reklamationsgespräche situations- gerecht führen und die weitere Bear- beitung koordinieren||X||x|||LF 5, 6, 7|
|o) Gewährleistungs- und Kulanzanträge bearbeiten||X||x|||LF 5, 6, 7|
|p) betriebliche Abläufe unter Berück- sichtigung von Informationsflüssen, Entscheidungswegen und Schnitt- stellen einordnen und mitgestalten||X|x|x|x||LF 1, 5, 11|
|q) eigenes Verhalten als Beitrag zur Kundenzufriedenheit und zur Kun- denbindung reflektieren und Schluss- folgerungen ziehen||X|x|x|||LF 1, 5, 6, 7|


**4.** **Betriebliche Marketingaktivitäten**
**planen und durchführen**


-----

|Ausbildungsrahmenplan Stand : 23.5.2016|Col2|Col3|Rahmenlehrplan Stand: 23.5.2016|Col5|Col6|Col7|Col8|
|---|---|---|---|---|---|---|---|
|Teil des Ausbildungsberufsbildes|Zeitliche Zuord- nung 1.-15. 16.-36. Monat Monat||Schuljahr 1 2 3 4||||Lernfelder|
|||||||||
|a) datenschutzrechtliche Vorschriften im Umgang mit Kundendaten einhalten|X|||x|x||LF 7, 12|
|b) Kundenzufriedenheit ermitteln und auswerten sowie regionale Wettbewerber beobachten|X|||x|x||LF 7, 12|
|c) Kontaktdaten für die Kundenakquise beschaffen|X|||x|x||LF 6, 12|
|d) Kundendaten zielgerichtet aufberei- ten und mit Hilfe entsprechender Pro- gramme verarbeiten und pflegen|X|||x|x||LF 6, 12|
|e) Maßnahmen zur Verkaufsförderung unter Einsatz geeigneter Werbemittel und -träger durchführen sowie bei der Er- folgskontrolle mitwirken|X||x|x|x||LF 4, 7, 12|
|f) Entwicklung von Marketingkonzep- ten unterstützen und dabei die Wettbe- werbssituation des Betriebes einbeziehen und wettbewerbsrechtliche Vorschriften einhalten||X|||x||LF 12|
|g) Sonderaktionen und Veranstaltun- gen planen, innerbetrieblich abstimmen, organisieren und durchführen||X|||x||LF12|
|h) Sponsoringanfragen bearbeiten und Sponsoring- und Kooperationsverträge vorbereiten und überwachen||X|||x||LF 12|
|i) digitale Medien für Marketingmaß- nahmen nutzen||X|x|x|x||LF 4, 7, 12|
|j) den Informationsaustausch zwi- schen den betrieblichen Geschäftsfeldern als Voraussetzung für ein erfolgreiches Marketing fördern und nutzen||X|||x||LF 10, 12|
|k) Marketingmaßnahmen hinsichtlich ihrer Zielsetzung reflektieren und Verbes- serungsmaßnahmen ableiten||X|x|x|x||LF 4, 7, 12|
|5. Fahrzeughandel und -vertrieb unterstützen||||||||
|a) bei der Unterstützung des Fahr- zeughandels und -vertriebs rechtliche Vorgaben, betriebliche Regelungen und technische Normen einhalten||X||x|||LF 6, 7|
|b) Neu- und Gebrauchtwagen unter Berücksichtigung verschiedener Fahr- zeugtypen einkaufen und dabei Kauf- und Werkvertragsrecht einhalten sowie Fi- nanzierungsspielräume berücksichtigen||X||x|||LF 6, 7|


-----

|Ausbildungsrahmenplan Stand : 23.5.2016|Col2|Col3|Rahmenlehrplan Stand: 23.5.2016|Col5|Col6|Col7|Col8|
|---|---|---|---|---|---|---|---|
|Teil des Ausbildungsberufsbildes|Zeitliche Zuord- nung 1.-15. 16.-36. Monat Monat||Schuljahr 1 2 3 4||||Lernfelder|
|||||||||
|c) Liefertermine überwachen||X||x|||LF 6|
|d) Einkaufs- und Verkaufskonditionen unter Einhaltung bestehender Vertriebs- verträge ausschöpfen und deren Erfül- lung überwachen||X||x|||LF 6, 7|
|e) Fahrzeugeinkauf, -ankauf und - inzahlungnahme erfassen||X||x|||LF 7|
|f) den verkaufsfertigen Zustand von Fahrzeugen veranlassen und überprüfen||X||x|||LF 6, 7|
|g) Vertriebssysteme für den Fahrzeug- handel unterscheiden, Vertriebswege, insbesondere Onlinehandel, nutzen||X||x|||LF 6, 7|
|h) Probefahrten organisieren;||X||x|||LF 6|
|i) Kundenbestellungen dokumentieren||X||x|||LF 6, 7|
|j) Fahrzeugzulassungen und - abmeldungen vorbereiten und durchfüh- ren||X||x|||LF 6|
|k) Fahrzeugübergaben vorbereiten||X||x|||LF 6|
|l) Informationen zur Kundenzufrieden- heit nach Fahrzeugauslieferung erfragen und dokumentieren||X||x|||LF 6|
|m) die eigene Vorgehensweise insbe- sondere hinsichtlich der Einhaltung be- trieblicher Qualitätsvorgaben reflektieren und bewerten und Maßnahmen zur Opti- mierung ableiten||X||x|||LF 6|
|6. Finanzdienstleistungsprodukte im Fahrzeughandel vorbereiten||||||||
|a) Bei der Vorbereitung von Finanz- dienstleistungsprodukten die Finanz- markt- und Wettbewerbssituation berück- sichtigen sowie die Rechtsgrundlagen zum Vertragswesen anwenden||X||x|||LF 8|
|b) Finanzierungsmodelle vergleichen, Finanzierungsangebote bedarfsgerecht erstellen und den Kunden unterbreiten||X||x|||LF 8|
|c) Leasingmodelle vergleichen, Lea- singangebote bedarfsgerecht erstellen und den Kunden unterbreiten||X||x|||LF 8|
|d) Versicherungsprodukte vergleichen, Versicherungsangebote bedarfsgerecht erstellen und den Kunden unterbreiten||X||x|||LF 8|


-----

|Ausbildungsrahmenplan Stand : 23.5.2016|Col2|Col3|Rahmenlehrplan Stand: 23.5.2016|Col5|Col6|Col7|Col8|
|---|---|---|---|---|---|---|---|
|Teil des Ausbildungsberufsbildes|Zeitliche Zuord- nung 1.-15. 16.-36. Monat Monat||Schuljahr 1 2 3 4||||Lernfelder|
|||||||||
|e) zusätzlich erwerbbare Garantieleis- tungen bedarfsgerecht anbieten||X||x|||LF 8|
|f) Verträge unterschriftsreif vorberei- ten und dokumentieren||X||x|||LF 8|
|g) Laufzeiten der Verträge kontrollieren und Anschlussmaßnahmen einleiten||X||x|||LF 8|
|h) die eigene Vorgehensweise auch unter Berücksichtigung betrieblicher Qua- litätsvorgaben reflektieren, bewerten und Maßnahmen zur Optimierung ableiten||X||x|||LF 8|
|7. Personalbezogene Aufgaben bearbeiten||||||||
|a) die Regelungen zum Datenschutz und zur Datensicherheit bei der Bearbei- tung von personenbezogenen Daten einhalten||X|||x||LF 9|
|b) arbeits-, sozial-, mitbestimmungs- und tarifrechtliche Vorschriften bei der Bearbeitung von personalbezogenen Aufgaben einhalten||X|||x||LF 9|
|c) Personalbedarfsermittlung unter Berücksichtigung von Anforderungsprofi- len unterstützen||X|||x||LF 9|
|d) im Personalbeschaffungsprozess mitwirken, insbesondere bei Stellenaus- schreibungen, Auswahlverfahren und Entscheidungsfindungen||X|||x||LF 9|
|e) bei Einstellungen und personellen Veränderungen erforderliche Meldungen veranlassen, Verträge vorbereiten und Schriftstücke erstellen||X|||x||LF 9|
|f) bereichsbezogene Personalstatisti- ken führen und auswerten||X|||x||LF 9|
|g) nach betrieblichen Vorgaben den Personaleinsatz planen und dabei Ar- beitszeitregelungen einhalten||X|||x||LF 9|
|h) Reisekostenabrechnungen bearbei- ten||X|||x||LF 9|
|i) Prämien und Provisionen nach vorgegebenen Schemata ermitteln und Entgeltabrechnungen vorbereiten||X|||x||LF 9|
|j) Notwendige Unterlagen zum Mo- nats- und Jahresabschluss unter Einhal- tung der Fristen aufbereiten||X|||x||LF 9|


-----

|Ausbildungsrahmenplan Stand : 23.5.2016|Col2|Col3|Rahmenlehrplan Stand: 23.5.2016|Col5|Col6|Col7|Col8|
|---|---|---|---|---|---|---|---|
|Teil des Ausbildungsberufsbildes|Zeitliche Zuord- nung 1.-15. 16.-36. Monat Monat||Schuljahr 1 2 3 4||||Lernfelder|
|||||||||
|k) Arbeitsabläufe im Hinblick auf Per- sonalplanung und -einsatz bewerten und reflektieren und Maßnahmen zur Optimie- rung vorschlagen||X|||x||LF 9|
|8. Kaufmännische Steuerung und Kontrolle unterstützen||||||||
|a) kaufmännische Steuerung und Kon- trolle unter Einhaltung der rechtlichen und betrieblichen Vorgaben unterstützen||X|x|x|x||LF 2 - 7, 10|
|b) Einflussgrößen auf die Wirtschaft- lichkeit der betrieblichen Leistungserstel- lung berücksichtigen||X|x||x||LF 2, 10, 11|
|c) Buchungsvorgänge bearbeiten||X|x|x|x||LF 2 – 7, 10|
|d) Kassenbücher führen||X|x|x|||LF 2, 6, 7|
|e) Bestands- und Erfolgskonten führen||X|x||x||LF 2, 10|
|f) Zahlungsein- und –ausgänge kon- trollieren, Offene-Posten-Listen führen und Maßnahmen bei Zahlungsverzug einleiten||X|x||x||LF 2, 10|
|g) Inventuren terminieren und durch- führen und die Ergebnisse für die Vorbe- reitung des Jahresabschlusses nutzen||X|x||x||LF 2, 10|
|h) am buchhalterischen Jahresab- schluss mitwirken;||X|x||x||LF 2, 10|
|i) auftragsbezogene Kosten überwa- chen und kontrollieren||X|x|x|x||LF 2, 5, 6, 7, 10|
|j) Verkaufspreise kalkulieren||X||x|x||LF 7, 10|
|k) betriebliche Kennzahlen unter An- wendung der Voll- und Teilkostenrech- nung ermitteln, beurteilen und für unter- nehmerische Entscheidungen aufbereiten||X|x|x|x||LF 2, 5, 6, 7, 10|
|l) Daten zur Kalkulation für unterneh- merische Entscheidungen aufbereiten||X||x|x||LF 7, 10|
|m) die eigene Vorgehensweise hin- sichtlich Genauigkeit und Korrektheit bewerten und Verbesserungsmaßnah- men ableiten||X|x|x|x||LF 2 – 7, 10|
|1. Berufsbildung, Arbeits- und Tarif- recht||||||||
|a) Bedeutung des Ausbildungsvertra- ges, insbesondere Abschluss, Dauer und Beendigung, erklären|X|X|x||||LF 1|


-----

|Ausbildungsrahmenplan Stand : 23.5.2016|Col2|Col3|Rahmenlehrplan Stand: 23.5.2016|Col5|Col6|Col7|Col8|
|---|---|---|---|---|---|---|---|
|Teil des Ausbildungsberufsbildes|Zeitliche Zuord- nung 1.-15. 16.-36. Monat Monat||Schuljahr 1 2 3 4||||Lernfelder|
|||||||||
|b) gegenseitige Rechte und Pflichten aus dem Ausbildungsvertrag nennen|X|X|x||||LF 1|
|c) Möglichkeiten der beruflichen Fort- bildung nennen|X|X|x||||LF 1|
|d) wesentliche Teile des Arbeitsvertra- ges nennen|X|X|x||||LF 1|
|e) wesentliche Bestimmungen der für den ausbildenden Betrieb geltenden Tarifverträge nennen|X|X|x||||LF 1|
|2. Aufbau und Organisation des Ausbildungsbetriebes||||||||
|a) den organisatorischen Aufbau des Ausbildungsbetriebs mit seinen Aufgaben und Zuständigkeiten sowie deren Zu- sammenwirken entlang der Wertschöp- fungskette erläutern|X|X|x|x|x||LF 1, 5, 11|
|b) Beziehungen des ausbildenden Betriebes und seiner Belegschaft zu Wirtschaftsorganisationen, Berufsvertre- tungen und Gewerkschaften nennen|X|X|x||x||LF 1, 9|
|c) Grundlagen, Aufgaben und Arbeits- weise der betriebsverfassungsrechtlichen Organe des ausbildenden Betriebes beschreiben|X|X|x||x||LF 1, 9|
|3. Sicherheit und Gesundheitsschutz bei der Arbeit||||||||
|a) Gefährdung von Sicherheit und Gesundheit am Arbeitsplatz feststellen und Maßnahmen zu ihrer Vermeidung ergreifen|X|X|x|x|x||LF 1, 5, 9|
|b) berufsbezogene Arbeitsschutz- und Unfallverhütungsvorschriften anwenden|X|X|x|x|x||LF 1, 5, 9|
|c) Verhaltensweisen bei Unfällen be- schreiben sowie erste Maßnahmen einlei- ten|X|X|x|x|x||LF 1, 5, 9|
|d) Vorschriften des vorbeugenden Brandschutzes anwenden; Verhaltens- weisen bei Bränden beschreiben und Maßnahmen zur Brandbekämpfung er- greifen|X|X|x|x|x||LF 1, 5, 9|
|4. Umweltschutz||||||||


-----

|Ausbildungsrahmenplan Stand : 23.5.2016|Col2|Col3|Rahmenlehrplan Stand: 23.5.2016|Col5|Col6|Col7|Col8|
|---|---|---|---|---|---|---|---|
|Teil des Ausbildungsberufsbildes|Zeitliche Zuord- nung 1.-15. 16.-36. Monat Monat||Schuljahr 1 2 3 4||||Lernfelder|
|||||||||
|Zur Vermeidung betriebsbedingter Um- weltbelastungen im beruflichen Einwir- kungsbereich beitragen, insbesondere a) mögliche Umweltbelastungen durch den Ausbildungsbetrieb und seinen Bei- trag zum Umweltschutz an Beispielen erklären|X|X|x|x|x||LF 1, 3 – 5, 11|
|b) für den Ausbildungsbetrieb geltende Regelungen des Umweltschutzes an- wenden|X|X|x|x|x||LF 1, 3 – 5, 11|
|c) Möglichkeiten der wirtschaftlichen und umweltschonenden Energie- und Materialverwendung nutzen|X|X|x|x|x||LF 1, 3 – 5, 11|
|d) Abfälle vermeiden; Stoffe und Mate- rialien einer umweltschonenden Entsor- gung zuführen|X|X|x|x|x||LF 1, 3 – 5, 11|


-----

